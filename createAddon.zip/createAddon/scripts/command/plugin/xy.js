export default class default_1 {
    static ms = {
        second: 1000,
        minute: 60000,
        hour: 3600000,
        day: 86400000,
        week: 604800000,
        month: 2592000000,
        year: 31536000000,
    };
    /**
     * @description Calculate the angle with rotation Y of pos1 (horiozontal) between two points
     */
    static caulateAngle(pos1, pos2, rotationY) {
        const commonAngle = (Math.atan2(pos2.z - pos1.z, pos2.x - pos1.x) * 180) / Math.PI;
        const rotatedAngle = commonAngle - rotationY - 90;
        const finalAngle = rotatedAngle <= -180 ? rotatedAngle + 360 : rotatedAngle;
        return Math.abs(finalAngle);
    }
    static distanceXZ(pos1, pos2) {
        return Math.hypot(pos1.x - pos2.x, pos1.z - pos2.z);
    }
    static distanceXYZ(pos1, pos2) {
        return Math.hypot(pos1.x - pos2.x, pos1.y - pos2.y, pos1.z - pos2.z);
    }
    static calculateDifferentSum(numberArray) {
        return numberArray.slice(1).reduce((sum, current, index) => sum + (current - numberArray[index]), 0) / (numberArray.length - 1);
    }
    static trackIncreasing(numberArray, min, max) {
        let increasing = false;
        let combo = 0;
        let maxCombo = 0;
        for (let i = 0; i < numberArray.length - 1; i++) {
            if (numberArray[i] < numberArray[i + 1]) {
                combo = 0;
            }
            else {
                combo++;
            }
            if (combo >= min) {
                if (combo > maxCombo) {
                    maxCombo = combo;
                }
            }
        }
        if (maxCombo >= min && maxCombo <= max) {
            increasing = true;
        }
        return increasing;
    }
    static comparing(a, b) {
        return Math.min(a / b, b / a);
    }
    static randomOffset(min, max) {
        return { x: Math.random() * (max - min) + min, z: Math.random() * (max - min) + min };
    }
    static desending(list) {
        return list.sort((a, b) => b - a);
    }
    static ascending(list) {
        return list.sort((a, b) => a - b);
    }
}
