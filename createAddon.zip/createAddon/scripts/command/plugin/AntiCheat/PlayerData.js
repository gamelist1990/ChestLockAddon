//AntiCheat/PlayerData.ts
import { GameMode } from '@minecraft/server';
export class PlayerDataManager {
    playerData = {};
    initialize(player) {
        this.playerData[player.id] = {
            lastGroundY: 0,
            originalGamemode: GameMode.survival,
            lastFallDistance: 0,
            positionHistory: [player.location],
            lastTime: Date.now(),
            violationCount: 0,
            isTeleporting: false,
            lastBlinkCheck: 0,
            lastTeleportTime: 0,
            jumpStartTime: 0,
            lastSpeedCheck: 0,
            speedViolationCount: 0,
            isFrozen: false,
            airJumpDetected: false,
            freezeStartTime: 0,
            isJumping: false,
            jumpCounter: 0,
            enderPearlInterval: null,
            recentlyUsedEnderPearl: false,
            lastRotationY: 0,
            boundaryCenter: player.location,
            boundaryRadius: 10,
            beingHit: false,
            xrayData: {
                suspiciousBlocks: {},
            },
            lastDamageTime: null,
            lastBreakBlockTime: null,
            lastAttackTime: 0,
            blinkCount: 0,
            attackFrequency: [],
            lastAttackedEntity: null,
            aimbotTicks: 0,
            throughBlockHits: {},
            flyHackCount: 0,
            lastAttackedEntities: [],
            lastMessages: [],
            lastVelocity: {
                vertical: 0,
                horizontal: 0,
            },
            lastMessageTimes: [],
            mutedUntil: 0,
            lastOnGroundTime: 0,
            lastPosition: player.location,
            badWordCount: 0,
        };
    }
    getPlayerData() {
        return this.playerData;
    }
    get(player) {
        return this.playerData[player.id];
    }
    update(player, newData) {
        const data = this.get(player);
        if (data) {
            Object.assign(data, newData);
        }
    }
    reset(player) {
        const data = this.get(player);
        if (data) {
            data.positionHistory = [player.location];
            data.lastTime = Date.now();
            data.lastTeleportTime = 0;
        }
    }
    remove(player) {
        delete this.playerData[player.id];
    }
    has(player) {
        return this.playerData[player.id] !== undefined;
    }
}
