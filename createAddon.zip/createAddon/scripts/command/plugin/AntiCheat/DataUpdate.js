export function updatePlayerData(player, playerDataManager, newData) {
    const data = playerDataManager.get(player);
    if (!data)
        return;
    playerDataManager.update(player, newData);
}
