import { config } from '../../Modules/Util';
import { registerCommand, verifier } from '../../Modules/Handler';
import { minecraftChatbot } from '../../Modules/mikaAI';
registerCommand({
    name: 'prompt',
    description: 'prompt Command',
    parent: false,
    maxArgs: 1,
    minArgs: 0,
    require: (player) => verifier(player, config().commands['prompt']),
    executor: (player, args) => {
        if (args.length > 0) {
            let response = minecraftChatbot(args[0]);
            player.sendMessage(response);
        }
    },
});
