import { closeForm, config, kick, tempkick } from '../../Modules/Util';
import { isPlayer, registerCommand, verifier } from '../../Modules/Handler';
import { GameMode, system, world } from '@minecraft/server';
import { checkReports, notifyStaff, resetReports } from './report';
import { translate } from '../langs/list/LanguageManager';
function announce(player, message) {
    world.sendMessage(`§l§f[§bServer§f]: ${message}`);
    player.sendMessage(`World Send Done..`);
}
const playerLocations = new Map();
const trackingIntervals = new Map();
const activeFreecamPlayers = new Set();
const playerWarnings = new Map();
function savePlayerLocation(player) {
    playerLocations.set(player.name, { location: player.location, dimension: player.dimension, gamemode: player.getGameMode() });
}
function teleportPlayerToLocation(player, location, dimension, callback) {
    const options = { dimension: dimension };
    system.runTimeout(() => {
        player.teleport(location, options);
        if (callback) {
            callback();
        }
    }, 1);
}
function setPlayerToSpectator(player) {
    system.runTimeout(() => {
        player.setGameMode(GameMode.spectator);
    }, 1);
}
function restorePlayerLocation(player) {
    const savedLocation = playerLocations.get(player.name);
    if (savedLocation) {
        const options = { dimension: savedLocation.dimension };
        system.runTimeout(() => {
            player.teleport(savedLocation.location, options);
            player.setGameMode(savedLocation.gamemode);
        }, 1);
    }
    else {
        player.sendMessage(translate(player, "Invalid"));
    }
}
const nightVisionEffectId = "night_vision";
const nightVisionEffectDuration = 1;
function startTrackingPlayer(player, targetPlayer) {
    const intervalId = system.runInterval(() => {
        try {
            system.runTimeout(() => {
                if (player.getGameMode() !== GameMode.spectator) {
                    setPlayerToSpectator(player);
                }
                player.addEffect(nightVisionEffectId, nightVisionEffectDuration);
                // ターゲットプレイヤーの回転情報を取得
                const targetRotation = targetPlayer.getRotation();
                // 視線方向ベクトルを取得
                const viewVector = getDirectionVector(targetRotation.y, targetRotation.x);
                const offsetDistance = 0.5;
                const targetLocationOffset = {
                    x: targetPlayer.location.x + viewVector.x * offsetDistance,
                    y: targetPlayer.location.y + viewVector.y * offsetDistance * 0.2,
                    z: targetPlayer.location.z + viewVector.z * offsetDistance,
                };
                player.teleport(targetLocationOffset, {
                    dimension: targetPlayer.dimension,
                    rotation: targetRotation,
                });
                player.setRotation(targetRotation);
            }, 1);
        }
        catch (error) {
            player.sendMessage(`Error getting view direction: ${error}`);
        }
        // 対象プレイヤーが存在しない場合の処理
        if (!targetPlayer || !targetPlayer.isValid()) {
            player.sendMessage(translate(player, "server.PlayerNotFound"));
            restorePlayerLocation(player);
            stopTrackingPlayer(player);
            activeFreecamPlayers.delete(player.name);
        }
    }, 1);
    trackingIntervals.set(player.name, intervalId);
}
// 視線方向ベクトルを取得する関数
function getDirectionVector(yaw, pitch) {
    const yawRad = (-yaw - 90) * (Math.PI / 180); // ラジアンに変換
    const pitchRad = pitch * (Math.PI / 180); // ラジアンに変換
    return {
        x: Math.cos(pitchRad) * Math.cos(yawRad),
        y: Math.sin(pitchRad),
        z: -Math.cos(pitchRad) * Math.sin(yawRad),
    };
}
function stopTrackingPlayer(player) {
    const intervalId = trackingIntervals.get(player.name);
    if (intervalId !== undefined) {
        system.clearRun(intervalId);
        trackingIntervals.delete(player.name);
    }
}
function warnPlayer(player, targetPlayer, reason, kickFlag) {
    const warnings = playerWarnings.get(targetPlayer.name) || { count: 0, reasons: [] };
    warnings.count += 1;
    warnings.reasons.push(reason);
    playerWarnings.set(targetPlayer.name, warnings);
    //targetPlayer.sendMessage(`You have been warned. Reason: ${reason}. Total warnings: ${warnings.count}`);
    translate(player, "command.warn.WarnTarget", { reason: `${reason}`, warnings: `${warnings.count}` }, targetPlayer);
    player.sendMessage(translate(player, "command.warn.WarnPlayer", { target: `${targetPlayer.name}`, warnings: `${warnings.count}`, reason: `${reason}` }));
    notifyStaff(player.name, targetPlayer.name);
    if (kickFlag) {
        kick(targetPlayer, `§cYou have been kicked for receiving §e${warnings.count} warnings. Reasons: §b${warnings.reasons.join(', ')}
`, player.name);
        player.sendMessage(translate(player, "command.warn.WarnKickMes", { target: `${targetPlayer.name}`, warnings: `${warnings.count}` }));
        playerWarnings.delete(targetPlayer.name);
    }
    if (warnings.count >= 3) {
        tempkick(targetPlayer);
        player.sendMessage(translate(player, "command.warn.WarnKickMes", { target: `${targetPlayer.name}`, warnings: `${warnings.count}` }));
        playerWarnings.delete(targetPlayer.name);
    }
}
registerCommand({
    name: 'staff',
    description: 'staff_docs',
    parent: false,
    maxArgs: 100,
    minArgs: 1,
    require: (player) => verifier(player, config().commands['staff']),
    executor: (player, args) => {
        const subCommand = args[0];
        const option = args[1];
        if (subCommand === 'freecam' && activeFreecamPlayers.has(player.name) && option !== '-exit') {
            player.sendMessage(translate(player, "command.staff.NoFreecam"));
            return;
        }
        if (subCommand === 'world') {
            if (option === '-send') {
                const message = args[2];
                announce(player, message);
            }
        }
        else if (subCommand === 'report') {
            if (option === '-check') {
                player.sendMessage(translate(player, "server.closeChat"));
                system.runTimeout(() => {
                    closeForm(player);
                    checkReports(player);
                }, 0);
            }
            else if (option === '-reset') {
                resetReports();
            }
        }
        else if (subCommand === 'freecam') {
            if (option === '-p') {
                const targetName = args[2];
                const targetPlayer = isPlayer(targetName);
                if (targetPlayer) {
                    savePlayerLocation(player);
                    teleportPlayerToLocation(player, targetPlayer.location, targetPlayer.dimension);
                    setPlayerToSpectator(player);
                    activeFreecamPlayers.add(player.name);
                }
                else {
                    player.sendMessage(translate(player, "commands.list.PlayerNotFound", { targetPlayer: `${targetName}` }));
                }
            }
            else if (option === '-s') {
                savePlayerLocation(player);
                setPlayerToSpectator(player);
                activeFreecamPlayers.add(player.name);
            }
            else if (option === '-exit') {
                restorePlayerLocation(player);
                stopTrackingPlayer(player); // 追従を停止
                activeFreecamPlayers.delete(player.name);
            }
            else if (option === '-v') {
                const targetName = args[2];
                const targetPlayer = isPlayer(targetName);
                if (targetPlayer) {
                    savePlayerLocation(player); // 自分の位置を保存
                    teleportPlayerToLocation(player, targetPlayer.location, targetPlayer.dimension, () => {
                        const viewDirection = targetPlayer.getViewDirection();
                        const rotation = { x: viewDirection.x, y: viewDirection.y };
                        player.setRotation(rotation);
                    });
                    startTrackingPlayer(player, targetPlayer);
                    activeFreecamPlayers.add(player.name);
                }
                else {
                    player.sendMessage(translate(player, "commands.list.PlayerNotFound", { targetPlayer: `${targetName}` }));
                }
            }
        }
        else if (subCommand === 'warn') {
            if (option === '-p') {
                const targetName = args[2];
                const reasonIndex = args.indexOf('-r');
                const reason = reasonIndex !== -1 ? args.slice(reasonIndex + 1).join(' ') : 'No reason provided';
                const kickFlag = args.includes('-kick');
                const targetPlayer = isPlayer(targetName);
                if (targetPlayer) {
                    warnPlayer(player, targetPlayer, reason, kickFlag);
                }
                else {
                    player.sendMessage(translate(player, "commands.list.PlayerNotFound", { targetPlayer: `${targetName}` }));
                }
            }
        }
        else {
            player.sendMessage(translate(player, "command.staff.UsageCom"));
        }
    },
});
