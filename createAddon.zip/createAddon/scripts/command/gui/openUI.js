import { closeForm, config } from '../../Modules/Util';
import { registerCommand, verifier } from '../../Modules/Handler';
import { showBasicUI } from './ui';
import { system } from '@minecraft/server';
import { translate } from '../langs/list/LanguageManager';
registerCommand({
    name: 'ui',
    description: 'ui_docs',
    parent: false,
    maxArgs: 0,
    minArgs: 0,
    require: (player) => verifier(player, config().commands['ui']),
    executor: (player) => {
        player.sendMessage(translate(player, 'server.closeChat'));
        system.runTimeout(() => {
            closeForm(player);
            showBasicUI(player);
        }, 0);
    },
});
