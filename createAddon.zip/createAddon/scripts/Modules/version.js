export const ver = '1.5-Beta';
