import { world } from '@minecraft/server';
import { config } from './Util';
export let chestLockAddonData = {};
export function saveData(key, value) {
    chestLockAddonData[key] = value;
    const data = JSON.stringify(chestLockAddonData);
    world.setDynamicProperty('ChestLockAddonData', data);
}
// データの読み込み関数
export function loadData() {
    const data = world.getDynamicProperty('ChestLockAddonData');
    if (data && typeof data === 'string') {
        chestLockAddonData = JSON.parse(data);
    }
}
// データの出力関数
export function logData() {
    console.warn(JSON.stringify(chestLockAddonData, null, 2));
}
// ResetData
export function resetData() {
    chestLockAddonData = {};
    if (config().module.debugMode.enabled === true) {
        console.warn('ChestLockAddon Data reset');
    }
    world.sendMessage("§l§eWarn §aChestLockAddon DataBase is Reset");
}
