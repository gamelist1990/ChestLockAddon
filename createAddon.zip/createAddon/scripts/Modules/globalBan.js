export const banPlayers = [
    { name: "Elm11336600" },
    { name: "baranokishi3605" },
    { name: "beastieB77" },
    { id: "-1404454304539" },
];
