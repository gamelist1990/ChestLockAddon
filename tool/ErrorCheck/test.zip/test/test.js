//エラー確認用JS


function greet(name) {
    console.log("Hello, " + namse); 
}

greet("world");

let x = 10; 
let y = 20; 
console.log(x + y); 

const player = {
    name: "Steve",
    health: 20
};